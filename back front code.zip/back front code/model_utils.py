import dill
import numpy as np
import pandas as pd
import warnings
warnings.filterwarnings('ignore')

class SmartFakeProfileDetector:
    def __init__(self, model_path):
        self.model = self.load_model(model_path)
        self.feature_names = [
            'profile pic',
            'nums/length username',
            'fullname words',
            'nums/length fullname',
            'name==username',
            'description length',
            'external URL',
            'private',
            '#posts',
            '#followers',
            '#follows'
        ]
        
    def load_model(self, model_path):
        """Load the XGBoost model with error handling"""
        try:
            with open(model_path, 'rb') as f:
                model = dill.load(f)
            print("✅ Model loaded successfully!")
            return model
        except Exception as e:
            print(f"⚠️ Could not load ML model: {e}")
            print("⚠️ Using rule-based detection only")
            return None
    
    def calculate_risk_score(self, data):
        """
        Calculate risk score based on patterns (0 to 1)
        Higher score = more likely fake
        """
        score = 0
        reasons = []
        
        # 1. Profile Picture (Weight: 15%)
        if data.get('profile pic') == 0:
            score += 0.15
            reasons.append("No profile picture")
        
        # 2. Username Analysis (Weight: 15%)
        username_ratio = data.get('nums/length username', 0)
        if username_ratio > 0.3:
            score += 0.15
            reasons.append(f"Username has {username_ratio*100:.0f}% numbers")
        elif username_ratio > 0.2:
            score += 0.08
            reasons.append("Username has some numbers")
        
        # 3. Full Name Analysis (Weight: 10%)
        fullname_ratio = data.get('nums/length fullname', 0)
        if fullname_ratio > 0.1:
            score += 0.10
            reasons.append("Numbers in full name")
        
        fullname_words = data.get('fullname words', 0)
        if fullname_words < 2:
            score += 0.05
            reasons.append("Incomplete full name")
        
        # 4. Name Match (Weight: 10%)
        name_match = data.get('name==username', 0)
        if name_match == 0:
            score += 0.10
            reasons.append("Name doesn't match username")
        
        # 5. Bio Analysis (Weight: 10%)
        description_len = data.get('description length', 0)
        if description_len == 0:
            score += 0.10
            reasons.append("Empty bio")
        elif description_len < 20:
            score += 0.05
            reasons.append("Very short bio")
        
        # 6. External URL (Weight: 5%)
        external_url = data.get('external URL', 0)
        if external_url == 1:
            score += 0.05
            reasons.append("Has external URL (possible spam)")
        
        # 7. Privacy (Weight: 5%)
        is_private = data.get('private', 0)
        if is_private == 1:
            score += 0.05
            reasons.append("Private account")
        
        # 8. Post Count (Weight: 10%)
        posts = data.get('#posts', 0)
        if posts == 0:
            score += 0.10
            reasons.append("No posts")
        elif posts < 5:
            score += 0.05
            reasons.append("Very few posts")
        
        # 9. Follower-Following Ratio (Weight: 15%)
        followers = data.get('#followers', 0)
        follows = data.get('#follows', 0)
        
        if followers == 0 and follows > 0:
            score += 0.15
            reasons.append("Following people but no followers")
        elif follows > 0 and followers > 0:
            ratio = follows / followers
            if ratio > 5:
                score += 0.15
                reasons.append(f"Following {ratio:.1f}x more than followers")
            elif ratio > 3:
                score += 0.08
                reasons.append("Imbalanced follower/following ratio")
        
        # 10. Suspicious Patterns (Bonus: 5%)
        if followers > 0 and posts == 0:
            score += 0.05
            reasons.append("Has followers but no posts (suspicious)")
        
        return min(score, 1.0), reasons
    
    def predict(self, profile_data):
        """
        Make prediction using ML model + smart rules
        """
        # Smart Rule-based Risk Score
        risk_score, risk_factors = self.calculate_risk_score(profile_data)
        
        # Try ML model if available
        ml_confidence = 0
        probability = risk_score
        
        if self.model is not None:
            try:
                # ML Model Prediction
                X = self.prepare_features(profile_data)
                proba = self.model.predict_proba(X)[0]
                probability = proba[1]  # Probability of being fake
                ml_confidence = max(proba) * 100
            except Exception as e:
                print(f"⚠️ ML prediction failed: {e}")
        
        # Combine both (Weight: 60% ML, 40% Rules if ML available)
        if self.model is not None:
            combined_score = (probability * 0.6) + (risk_score * 0.4)
        else:
            combined_score = risk_score
        
        # Determine prediction
        if combined_score > 0.6:
            prediction = 'FAKE'
        elif combined_score > 0.3:
            prediction = 'SUSPICIOUS'
        else:
            prediction = 'GENUINE'
        
        # Determine risk level
        if combined_score > 0.7:
            risk_level = "HIGH"
        elif combined_score > 0.4:
            risk_level = "MEDIUM"
        else:
            risk_level = "LOW"
        
        result = {
            'prediction': prediction,
            'confidence': float(combined_score * 100),
            'ml_confidence': float(ml_confidence),
            'risk_score': float(risk_score * 100),
            'risk_level': risk_level,
            'risk_factors': risk_factors,
            'probability': float(probability)
        }
        
        return result
    
    def prepare_features(self, data):
        """Prepare features for ML model"""
        features = []
        for feature in self.feature_names:
            features.append(data.get(feature, 0))
        return np.array(features).reshape(1, -1)
    
    def get_detailed_analysis(self, profile_data):
        """Generate detailed analysis for display"""
        analysis = []
        
        # Profile Picture
        if profile_data.get('profile pic') == 1:
            analysis.append(("✅ Has profile picture", "good"))
        else:
            analysis.append(("❌ No profile picture", "bad"))
        
        # Username
        username_ratio = profile_data.get('nums/length username', 0)
        if username_ratio < 0.2:
            analysis.append(("✅ Clean username", "good"))
        elif username_ratio < 0.4:
            analysis.append(("⚠️ Username has some numbers", "warning"))
        else:
            analysis.append((f"❌ Username is {username_ratio*100:.0f}% numbers", "bad"))
        
        # Full Name
        fullname_ratio = profile_data.get('nums/length fullname', 0)
        if fullname_ratio == 0:
            analysis.append(("✅ Clean full name", "good"))
        else:
            analysis.append((f"❌ Full name has {fullname_ratio*100:.0f}% numbers", "bad"))
        
        # Name Match
        if profile_data.get('name==username') == 1:
            analysis.append(("✅ Name matches username", "good"))
        else:
            analysis.append(("❌ Name doesn't match username", "bad"))
        
        # Bio
        bio_len = profile_data.get('description length', 0)
        if bio_len > 50:
            analysis.append(("✅ Detailed bio", "good"))
        elif bio_len > 10:
            analysis.append(("⚠️ Short bio", "warning"))
        else:
            analysis.append(("❌ Empty or very short bio", "bad"))
        
        # Posts
        posts = profile_data.get('#posts', 0)
        if posts > 50:
            analysis.append(("✅ Good number of posts", "good"))
        elif posts > 10:
            analysis.append(("⚠️ Moderate posts", "warning"))
        else:
            analysis.append((f"❌ Only {posts} posts", "bad"))
        
        # Followers/Following
        followers = profile_data.get('#followers', 0)
        follows = profile_data.get('#follows', 0)
        
        if followers > 100 and followers > follows:
            analysis.append(("✅ Healthy follower ratio", "good"))
        elif followers > 0:
            ratio = follows / followers if followers > 0 else 0
            if ratio > 3:
                analysis.append((f"❌ Following {ratio:.1f}x more than followers", "bad"))
            else:
                analysis.append(("⚠️ Moderate follower ratio", "warning"))
        else:
            analysis.append(("❌ No followers", "bad"))
        
        return analysis