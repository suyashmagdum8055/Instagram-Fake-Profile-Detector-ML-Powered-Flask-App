import os
import sys
import subprocess

def check_database():
    """Check if PostgreSQL is running"""
    try:
        import psycopg2
        conn = psycopg2.connect(
            database="postgres",
            user="postgres",
            password="",
            host="localhost"
        )
        conn.autocommit = True
        cursor = conn.cursor()
        
        # Create database if not exists
        cursor.execute("SELECT 1 FROM pg_catalog.pg_database WHERE datname = 'instagram_fake_db'")
        exists = cursor.fetchone()
        if not exists:
            cursor.execute("CREATE DATABASE instagram_fake_db")
            print("✅ Database 'instagram_fake_db' created!")
        else:
            print("✅ Database already exists")
        
        cursor.close()
        conn.close()
        return True
    except Exception as e:
        print(f"⚠️ PostgreSQL not available: {e}")
        print("⚠️ Using SQLite as fallback")
        return False

if __name__ == "__main__":
    print("="*50)
    print("Instagram Fake Profile Detector")
    print("="*50)
    
    # Check database
    has_postgres = check_database()
    
    if not has_postgres:
        print("\n📌 To use PostgreSQL:")
        print("1. Download from: https://www.postgresql.org/download/windows/")
        print("2. Install with default settings")
        print("3. Make sure service is running")
        print("\n💡 Continuing with SQLite (no password needed)...")
    
    print("\n🚀 Starting Flask application...")
    print("📱 Open http://localhost:5000 in your browser")
    print("="*50)
    
    # Run the app
    os.system("python app.py")