from flask import Flask, render_template, request, jsonify, redirect, url_for
from database import db, PredictionHistory
from config import Config
from model_utils import SmartFakeProfileDetector
import os

# Initialize Flask app
app = Flask(__name__)
app.config.from_object(Config)

# Initialize database
db.init_app(app)

# Initialize detector
detector = SmartFakeProfileDetector(Config.MODEL_PATH)

# Create tables
with app.app_context():
    db.create_all()
    print("✅ Database tables created!")

@app.route('/')
def index():
    """Home page"""
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    """Handle prediction request"""
    try:
        # Get form data with defaults
        profile_data = {
            'profile pic': int(request.form.get('profile_pic', 0)),
            'nums/length username': float(request.form.get('username_digit_ratio', 0)),
            'fullname words': int(request.form.get('fullname_words', 1)),
            'nums/length fullname': float(request.form.get('fullname_digit_ratio', 0)),
            'name==username': int(request.form.get('name_equals_username', 0)),
            'description length': int(request.form.get('description_length', 0)),
            'external URL': int(request.form.get('external_url', 0)),
            'private': int(request.form.get('is_private', 0)),
            '#posts': int(request.form.get('posts', 0)),
            '#followers': int(request.form.get('followers', 0)),
            '#follows': int(request.form.get('follows', 0))
        }
        
        username = request.form.get('username', 'Unknown User')
        
        # Get detailed analysis
        detailed_analysis = detector.get_detailed_analysis(profile_data)
        
        # Make prediction
        result = detector.predict(profile_data)
        
        if result is None:
            return render_template('result.html', error="Prediction failed. Please try again.")
        
        # Add analysis to result
        result['detailed_analysis'] = detailed_analysis
        result['profile_data'] = profile_data
        result['username'] = username
        
        # Save to database
        history = PredictionHistory(
            username=username,
            profile_pic=profile_data['profile pic'],
            username_digit_ratio=profile_data['nums/length username'],
            fullname_words=profile_data['fullname words'],
            fullname_digit_ratio=profile_data['nums/length fullname'],
            name_equals_username=profile_data['name==username'],
            description_length=profile_data['description length'],
            external_url=profile_data['external URL'],
            is_private=profile_data['private'],
            posts=profile_data['#posts'],
            followers=profile_data['#followers'],
            follows=profile_data['#follows'],
            prediction=result['prediction'],
            confidence=result['confidence'],
            risk_score=result['risk_score'],
            risk_level=result['risk_level']
        )
        
        db.session.add(history)
        db.session.commit()
        
        return render_template('result.html', result=result)
    
    except Exception as e:
        return render_template('result.html', error=f"Error: {str(e)}")

@app.route('/history')
def history():
    """View prediction history"""
    predictions = PredictionHistory.query.order_by(
        PredictionHistory.created_at.desc()
    ).limit(50).all()
    
    # Calculate stats
    total = len(predictions)
    fake_count = sum(1 for p in predictions if p.prediction == 'FAKE')
    genuine_count = sum(1 for p in predictions if p.prediction == 'GENUINE')
    suspicious_count = sum(1 for p in predictions if p.prediction == 'SUSPICIOUS')
    
    stats = {
        'total': total,
        'fake': fake_count,
        'genuine': genuine_count,
        'suspicious': suspicious_count,
        'fake_percentage': round((fake_count / total * 100) if total > 0 else 0, 1)
    }
    
    return render_template('history.html', predictions=predictions, stats=stats)

@app.route('/api/predict', methods=['POST'])
def api_predict():
    """API endpoint for predictions"""
    try:
        data = request.get_json()
        
        profile_data = {
            'profile pic': data.get('profile_pic', 0),
            'nums/length username': data.get('username_digit_ratio', 0),
            'fullname words': data.get('fullname_words', 1),
            'nums/length fullname': data.get('fullname_digit_ratio', 0),
            'name==username': data.get('name_equals_username', 0),
            'description length': data.get('description_length', 0),
            'external URL': data.get('external_url', 0),
            'private': data.get('is_private', 0),
            '#posts': data.get('posts', 0),
            '#followers': data.get('followers', 0),
            '#follows': data.get('follows', 0)
        }
        
        result = detector.predict(profile_data)
        
        if result is None:
            return jsonify({'error': 'Prediction failed'}), 500
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 400

@app.route('/api/stats')
def api_stats():
    """Get statistics"""
    total = PredictionHistory.query.count()
    fake_count = PredictionHistory.query.filter_by(prediction='FAKE').count()
    genuine_count = PredictionHistory.query.filter_by(prediction='GENUINE').count()
    suspicious_count = PredictionHistory.query.filter_by(prediction='SUSPICIOUS').count()
    
    return jsonify({
        'total': total,
        'fake': fake_count,
        'genuine': genuine_count,
        'suspicious': suspicious_count,
        'fake_percentage': round((fake_count / total * 100) if total > 0 else 0, 1)
    })

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)