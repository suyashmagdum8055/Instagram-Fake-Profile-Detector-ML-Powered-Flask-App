import os

class Config:
    # Database configuration (PostgreSQL without password)
    SQLALCHEMY_DATABASE_URI = 'postgresql://postgres@localhost/instagram_fake_db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = 'instagram-fake-detector-major-project-2024'
    
    # Model configuration
    MODEL_PATH = 'fake_account_model.pkl'
    
    # Detection thresholds
    HIGH_RISK_THRESHOLD = 0.7
    MEDIUM_RISK_THRESHOLD = 0.4