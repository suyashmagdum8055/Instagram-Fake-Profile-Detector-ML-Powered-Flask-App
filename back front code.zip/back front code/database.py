from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

class PredictionHistory(db.Model):
    __tablename__ = 'prediction_history'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), default='Unknown')
    
    # Features
    profile_pic = db.Column(db.Integer, default=0)
    username_digit_ratio = db.Column(db.Float, default=0.0)
    fullname_words = db.Column(db.Integer, default=1)
    fullname_digit_ratio = db.Column(db.Float, default=0.0)
    name_equals_username = db.Column(db.Integer, default=0)
    description_length = db.Column(db.Integer, default=0)
    external_url = db.Column(db.Integer, default=0)
    is_private = db.Column(db.Integer, default=0)
    posts = db.Column(db.Integer, default=0)
    followers = db.Column(db.Integer, default=0)
    follows = db.Column(db.Integer, default=0)
    
    # Results
    prediction = db.Column(db.String(20), default='Unknown')
    confidence = db.Column(db.Float, default=0.0)
    risk_score = db.Column(db.Float, default=0.0)
    risk_level = db.Column(db.String(20), default='LOW')
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'prediction': self.prediction,
            'confidence': f"{self.confidence:.1f}%",
            'risk_level': self.risk_level,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M'),
            'followers': self.followers,
            'follows': self.follows,
            'posts': self.posts
        }